"""Evaluation-only neighbour coverage annotation and mask bundle validation."""

from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

import numpy as np

import nb_fixtures as fx
from benchmark.nograph_baseline import coverage, protocol


class GraphCoverageTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.keys = fx.r0_keys(5)
        self.key_array = np.asarray(self.keys, dtype=np.int64)
        self.rows = [[0, 0, 1], [0, 1, 2], [0, 2, 2], [0, 3, 3]]
        self.graph_path = fx.write_graph(self.root / "r0.parquet", "r0", self.rows)

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_both_endpoints_covered_and_self_loops_excluded(self) -> None:
        result = coverage.load_graph_coverage(
            "r0", self.key_array, graph_path=self.graph_path
        )
        np.testing.assert_array_equal(
            result.mask, np.array([True, True, True, False, False])
        )
        self.assertEqual(result.provenance["self_loop_rows"], 2)
        self.assertEqual(result.provenance["directed_source_rows"], 4)
        self.assertEqual(result.provenance["covered_nodes"], 3)
        self.assertFalse(result.provenance["used_for_forecasting"])

    def test_unmatched_endpoint_fails_validation(self) -> None:
        bad = fx.write_graph(self.root / "bad.parquet", "r0", [[0, 0, 99]])
        with self.assertRaises(coverage.CoverageError):
            coverage.load_graph_coverage("r0", self.key_array, graph_path=bad)

    def test_missing_coverage_evidence_is_an_error(self) -> None:
        with self.assertRaises(coverage.CoverageError):
            coverage.load_graph_coverage(
                "r0", self.key_array, graph_path=self.root / "absent.parquet"
            )

    def test_same_skill_in_two_regions_is_context_qualified(self) -> None:
        keys = np.asarray([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=np.int64)
        rows = [[0, 0, 1], [1, 1, 1]]  # edge only in region 0, self-loop in region 1
        path = fx.write_graph(self.root / "region.parquet", "region", rows)
        result = coverage.load_graph_coverage("region", keys, graph_path=path)
        np.testing.assert_array_equal(
            result.mask, np.array([True, True, False, False])
        )


class MaskBundleTests(unittest.TestCase):
    def setUp(self) -> None:
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        self.key_array = np.asarray(fx.r0_keys(4), dtype=np.int64)
        self.mask = np.array([True, False, True, False])

    def tearDown(self) -> None:
        self._tmp.cleanup()

    def test_round_trip_with_exact_identity_alignment(self) -> None:
        path = self.root / "mask.npz"
        record = coverage.save_mask_bundle(
            path,
            "r0",
            self.key_array,
            self.mask,
            {"definition": "fixture", "source_sha256": "deadbeef"},
        )
        self.assertIn("bundle_sha256", record)
        loaded = coverage.load_mask_bundle(path, "r0", self.key_array)
        np.testing.assert_array_equal(loaded.mask, self.mask)
        self.assertEqual(loaded.provenance["source"], "mask_bundle")
        self.assertEqual(loaded.provenance["source_sha256"], record["bundle_sha256"])

    def test_wrong_node_keys_are_rejected(self) -> None:
        path = self.root / "mask.npz"
        coverage.save_mask_bundle(
            path, "r0", self.key_array, self.mask, {"definition": "fixture"}
        )
        other = np.asarray(fx.r0_keys(4), dtype=np.int64)
        other[0, 1] = 99
        with self.assertRaises(coverage.CoverageError):
            coverage.load_mask_bundle(path, "r0", other)

    def test_missing_bundle_is_an_error(self) -> None:
        with self.assertRaises(coverage.CoverageError):
            coverage.load_mask_bundle(self.root / "absent.npz", "r0", self.key_array)


if __name__ == "__main__":
    unittest.main()
