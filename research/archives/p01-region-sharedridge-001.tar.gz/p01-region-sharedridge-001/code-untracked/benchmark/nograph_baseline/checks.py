"""Saved-run analysis commands: recompute, compare and immutable v2 alignment.

None of these commands fits a model, reads source demand/graph data, or alters
its input runs.  Each reserves a fresh check-type run directory holding its
linked input hashes, command, report and terminal status.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

import numpy as np

from . import artifacts, metrics, protocol
from .data import sha256_file

#: Normalized tolerances used by saved-run checks.
CPU_RELATIVE_TOLERANCE = 1e-6
DIAGNOSTIC_RELATIVE_TOLERANCE = 1e-12


class CheckError(RuntimeError):
    """Raised when a saved-run check cannot be completed."""


def _read_json(path: Path) -> Any:
    if not path.exists():
        raise CheckError(f"required artifact is missing: {path}")
    return json.loads(path.read_text(encoding="utf-8"))


def _load_npy(path: Path) -> np.ndarray:
    if not path.exists():
        raise CheckError(f"required numeric artifact is missing: {path}")
    return np.load(path, allow_pickle=False)


def _load_npz(path: Path) -> Dict[str, np.ndarray]:
    if not path.exists():
        raise CheckError(f"required mask artifact is missing: {path}")
    with np.load(path, allow_pickle=False) as handle:
        return {name: np.asarray(handle[name]) for name in handle.files}


def _check_run(run_id: str, run_type: str, runs_root: Path) -> artifacts.RunDirectory:
    artifacts.validate_run_id(run_id)
    run = artifacts.RunDirectory(runs_root, run_id, run_type)
    return run.reserve()


def _write_check_provenance(
    run: artifacts.RunDirectory,
    *,
    command: Sequence[str],
    inputs: Mapping[str, Any],
    check: str,
    repo_root: Path,
) -> None:
    run.write_json(
        "command.json",
        {"argv": list(command), "cwd": str(Path.cwd())},
    )
    run.write_json(
        "config.json",
        {"check": check, "protocol_version": protocol.PROTOCOL_VERSION},
    )
    git = artifacts.capture_git(repo_root)
    artifacts.write_git_snapshot(run, git)
    run.write_json(
        "provenance.json",
        {
            "run_id": run.run_id,
            "run_type": run.run_type,
            "check": check,
            "created": _now(),
            "git": {
                "commit": git.get("commit"),
                "dirty": git.get("dirty"),
                "errors": git.get("errors"),
            },
            "inputs": dict(inputs),
            "scientific_acceptance": False,
        },
    )


def _now() -> str:
    from .data import iso_now

    return iso_now()


def _hash_tree(directory: Path, relative_paths: Iterable[str]) -> Dict[str, str]:
    hashes: Dict[str, str] = {}
    for relative in relative_paths:
        path = directory / relative
        if path.exists() and path.is_file():
            hashes[relative] = sha256_file(path)
    return hashes


# ---------------------------------------------------------------------------
# metric comparison helpers
# ---------------------------------------------------------------------------
def flatten_numbers(payload: Any, prefix: str = "") -> Dict[str, float]:
    """Flatten a nested structure to ``path -> finite number`` entries."""
    flat: Dict[str, float] = {}
    if isinstance(payload, Mapping):
        for key, value in payload.items():
            flat.update(flatten_numbers(value, f"{prefix}.{key}" if prefix else str(key)))
    elif isinstance(payload, (list, tuple)):
        for index, value in enumerate(payload):
            flat.update(flatten_numbers(value, f"{prefix}[{index}]"))
    elif isinstance(payload, bool):
        return flat
    elif isinstance(payload, (int, float)):
        value = float(payload)
        if math.isfinite(value):
            flat[prefix] = value
    return flat


def normalized_difference(a: float, b: float) -> float:
    """Return ``abs(a-b) / max(1, abs(a), abs(b))`` for tolerance checks."""
    return abs(a - b) / max(1.0, abs(a), abs(b))


def compare_number_sets(
    expected: Mapping[str, float],
    actual: Mapping[str, float],
    *,
    tolerance: float,
    label: str,
) -> Dict[str, Any]:
    """Compare two flattened numeric maps under a normalized tolerance."""
    common = sorted(set(expected) & set(actual))
    missing = sorted(set(expected) - set(actual))
    extra = sorted(set(actual) - set(expected))
    worst = 0.0
    worst_path = None
    failures: List[Dict[str, Any]] = []
    for path in common:
        difference = normalized_difference(expected[path], actual[path])
        if difference > worst:
            worst = difference
            worst_path = path
        if difference > tolerance:
            failures.append(
                {
                    "path": path,
                    "expected": expected[path],
                    "actual": actual[path],
                    "normalized_difference": difference,
                }
            )
    return {
        "label": label,
        "tolerance": tolerance,
        "compared_fields": len(common),
        "missing_fields": missing,
        "extra_fields": extra,
        "max_normalized_difference": worst,
        "max_difference_path": worst_path,
        "failed_fields": failures,
        "status": "ok" if not failures and not missing else "mismatch",
    }


# ---------------------------------------------------------------------------
# recompute
# ---------------------------------------------------------------------------
def command_recompute(
    *,
    run_dir: Path,
    run_id: str,
    runs_root: Path,
    repo_root: Path,
    command: Sequence[str],
) -> Dict[str, Any]:
    """Recompute every saved metric from a completed run directory only."""
    run_dir = Path(run_dir)
    if not run_dir.exists():
        raise CheckError(f"input run directory does not exist: {run_dir}")
    status = _read_json(run_dir / "status.json")
    metrics_document = _read_json(run_dir / "metrics.json")
    nodes = _read_nodes(run_dir / "nodes.parquet")
    key_columns = [column for column in nodes.columns if column != "node_index"]
    masks = _load_npz(run_dir / "masks.npz")
    windows_meta = _read_json(run_dir / "windows.json")
    splits = windows_meta["splits"]

    activity_masks = {
        name: masks[f"activity_{name}"]
        for name in protocol.ACTIVITY_GROUP_NAMES
        if f"activity_{name}" in masks
    }
    constant_masks = {
        "constant_train27": masks["constant_train27"],
        "nonconstant_train27": ~masks["constant_train27"],
    }
    neighbor_masks = {
        "has_nonself_neighbor": masks["has_nonself_neighbor"],
        "no_nonself_neighbor": ~masks["has_nonself_neighbor"],
    }
    context_values = nodes[key_columns[0]].to_numpy()
    context_masks_map = metrics.context_masks(context_values)

    check = _check_run(run_id, "recompute", runs_root)
    try:
        _write_check_provenance(
            check,
            command=command,
            check="recompute",
            repo_root=repo_root,
            inputs={
                "input_run_dir": str(run_dir),
                "input_run_id": status.get("run_id"),
                "input_status": status.get("state"),
                "input_artifacts": _hash_tree(
                    run_dir,
                    [
                        "metrics.json",
                        "nodes.parquet",
                        "masks.npz",
                        "windows.json",
                        "gold/validation.npy",
                        "gold/test.npy",
                        "status.json",
                    ],
                ),
            },
        )
        check.append_event("recompute_started", input_run=str(run_dir))
        recomputed: Dict[str, Dict[str, Any]] = {"validation": {}, "test": {}}
        for split in ("validation", "test"):
            gold = _load_npy(run_dir / "gold" / f"{split}.npy")
            starts = splits[split]
            for method_dir in sorted((run_dir / "predictions").iterdir()):
                if not method_dir.is_dir():
                    continue
                method = method_dir.name
                pred = _load_npy(method_dir / f"{split}.npy")
                if pred.shape != gold.shape:
                    raise CheckError(
                        f"{method}/{split}: prediction shape {pred.shape} != gold {gold.shape}"
                    )
                report = metrics.split_report(
                    pred,
                    gold,
                    starts=starts,
                    activity_masks=activity_masks,
                    constant_masks=constant_masks,
                    context_masks_map=context_masks_map,
                    neighbor_masks=neighbor_masks,
                )
                recomputed[split][method] = report
        stored = metrics_document["methods"]
        comparisons = {}
        for split in ("validation", "test"):
            comparisons[split] = compare_number_sets(
                flatten_numbers(stored[split]),
                flatten_numbers(recomputed[split]),
                tolerance=DIAGNOSTIC_RELATIVE_TOLERANCE,
                label=f"recompute:{split}",
            )
        check.write_json("recomputed-metrics.json", recomputed)
        failed = [
            name
            for name, comparison in comparisons.items()
            if comparison["status"] != "ok"
        ]
        report = {
            "check": "recompute",
            "input_run_dir": str(run_dir),
            "methods": sorted(
                method
                for method in recomputed["test"].keys()
            ),
            "comparisons": comparisons,
            "source_data_read": False,
            "model_refit": False,
            "status": "ok" if not failed else "mismatch",
        }
        check.write_json("report.json", report)
        check.write_text(
            "summary.md",
            f"# Recompute check {run_id}\n\n"
            f"- Input run: `{run_dir}`\n"
            f"- Methods: {', '.join(report['methods']) or 'none'}\n"
            f"- Result: {report['status']}\n"
            f"- Source demand/graph data was not read and no model was fit.\n",
        )
        check.set_status("success" if not failed else "failed", stage="complete")
        check.finalize_artifacts_manifest()
        return {"run_dir": str(check.path), "status": report["status"], "report": report}
    except BaseException as exc:  # noqa: BLE001
        check.set_status("failed", stage="recompute", error=repr(exc))
        raise


def _read_nodes(path: Path) -> "Any":
    import pandas as pd

    if not path.exists():
        raise CheckError(f"required artifact is missing: {path}")
    return pd.read_parquet(path)


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------
def command_compare(
    *,
    run_a: Path,
    run_b: Path,
    run_id: str,
    runs_root: Path,
    repo_root: Path,
    command: Sequence[str],
) -> Dict[str, Any]:
    """Compare two same-seed runs and apply the CPU agreement criterion."""
    run_a, run_b = Path(run_a), Path(run_b)
    for label, run_dir in (("a", run_a), ("b", run_b)):
        if not run_dir.exists():
            raise CheckError(f"run {label} does not exist: {run_dir}")
    status_a = _read_json(run_a / "status.json")
    status_b = _read_json(run_b / "status.json")
    metrics_a = _read_json(run_a / "metrics.json")
    metrics_b = _read_json(run_b / "metrics.json")
    config_a = _read_json(run_a / "config.json")
    config_b = _read_json(run_b / "config.json")
    selection_a = _read_json(run_a / "selection.json")
    selection_b = _read_json(run_b / "selection.json")
    source_a = _read_json(run_a / "source-sha256.json")
    source_b = _read_json(run_b / "source-sha256.json")

    check = _check_run(run_id, "compare", runs_root)
    try:
        _write_check_provenance(
            check,
            command=command,
            check="compare",
            repo_root=repo_root,
            inputs={
                "run_a": str(run_a),
                "run_b": str(run_b),
                "run_a_artifacts": _hash_tree(
                    run_a, ["metrics.json", "selection.json", "source-sha256.json"]
                ),
                "run_b_artifacts": _hash_tree(
                    run_b, ["metrics.json", "selection.json", "source-sha256.json"]
                ),
            },
        )
        check.append_event("compare_started")
        identity_checks = {
            "dataset": config_a.get("spec", {}).get("data_name")
            == config_b.get("spec", {}).get("data_name"),
            "protocol_version": metrics_a.get("protocol_version")
            == metrics_b.get("protocol_version"),
            "node_keys_sha256": source_a.get("node_keys_sha256")
            == source_b.get("node_keys_sha256"),
            "demand_sha256": _source_hash(source_a, "demand")
            == _source_hash(source_b, "demand"),
            "coverage_sha256": source_a.get("coverage_bundle_sha256")
            or _source_hash(source_a, "coverage")
            == (
                source_b.get("coverage_bundle_sha256")
                or _source_hash(source_b, "coverage")
            ),
            "selected_lambda": selection_a.get("shared_ridge", {}).get(
                "selected_lambda"
            )
            == selection_b.get("shared_ridge", {}).get("selected_lambda"),
            "naive_ref": selection_a.get("naive_references", {}).get("NaiveRef")
            == selection_b.get("naive_references", {}).get("NaiveRef"),
            "naive_ref6": selection_a.get("naive_references", {}).get("NaiveRef6")
            == selection_b.get("naive_references", {}).get("NaiveRef6"),
            "same_seed": config_a.get("spec", {}).get("seed")
            == config_b.get("spec", {}).get("seed"),
        }
        methods = sorted(
            set(metrics_a.get("methods", {}).get("test", {}))
            & set(metrics_b.get("methods", {}).get("test", {}))
        )
        prediction_comparisons: Dict[str, Any] = {}
        masks_equal = True
        masks_a = _load_npz(run_a / "masks.npz")
        masks_b = _load_npz(run_b / "masks.npz")
        for name in sorted(set(masks_a) | set(masks_b)):
            if name not in masks_a or name not in masks_b:
                masks_equal = False
                break
            if not np.array_equal(masks_a[name], masks_b[name]):
                masks_equal = False
                break
        for split in ("validation", "test"):
            for method in methods:
                path_a = run_a / "predictions" / method / f"{split}.npy"
                path_b = run_b / "predictions" / method / f"{split}.npy"
                pred_a = _load_npy(path_a)
                pred_b = _load_npy(path_b)
                if pred_a.shape != pred_b.shape:
                    prediction_comparisons[f"{split}/{method}"] = {
                        "status": "shape_mismatch",
                        "shape_a": list(pred_a.shape),
                        "shape_b": list(pred_b.shape),
                    }
                    continue
                first = pred_a.astype(np.float64)
                second = pred_b.astype(np.float64)
                absolute = np.abs(first - second)
                denominator = np.maximum(1.0, np.maximum(np.abs(first), np.abs(second)))
                normalized = absolute / denominator
                prediction_comparisons[f"{split}/{method}"] = {
                    "max_absolute_difference": float(absolute.max())
                    if absolute.size
                    else 0.0,
                    "max_normalized_difference": float(normalized.max())
                    if normalized.size
                    else 0.0,
                    "elementwise_violations": int(
                        (normalized > CPU_RELATIVE_TOLERANCE).sum()
                    ),
                    "status": "ok"
                    if normalized.size == 0
                    or float(normalized.max()) <= CPU_RELATIVE_TOLERANCE
                    else "mismatch",
                }
        metric_comparison = compare_number_sets(
            flatten_numbers(metrics_a.get("methods", {})),
            flatten_numbers(metrics_b.get("methods", {})),
            tolerance=CPU_RELATIVE_TOLERANCE,
            label="metrics",
        )
        mae_relative_differences: Dict[str, Any] = {}
        mae_ok = True
        for split in ("validation", "test"):
            for method in methods:
                report_a = metrics_a["methods"][split].get(method, {})
                report_b = metrics_b["methods"][split].get(method, {})
                mae_a = report_a.get("MAE")
                mae_b = report_b.get("MAE")
                if mae_a is None or mae_b is None:
                    continue
                relative = abs(mae_a - mae_b) / max(1.0, abs(mae_a), abs(mae_b))
                passes = relative <= CPU_RELATIVE_TOLERANCE
                mae_ok = mae_ok and passes
                mae_relative_differences[f"{split}/{method}"] = {
                    "MAE_a": mae_a,
                    "MAE_b": mae_b,
                    "relative_difference": relative,
                    "criterion": "abs(MAE_a-MAE_b)/max(1,MAE_a,MAE_b) <= 1e-6",
                    "status": "ok" if passes else "mismatch",
                }
        identity_ok = all(identity_checks.values())
        predictions_ok = all(
            value.get("status") == "ok" for value in prediction_comparisons.values()
        )
        overall_ok = (
            identity_ok
            and predictions_ok
            and metric_comparison["status"] == "ok"
            and mae_ok
            and masks_equal
        )
        report = {
            "check": "compare",
            "run_a": str(run_a),
            "run_b": str(run_b),
            "status_a": status_a.get("state"),
            "status_b": status_b.get("state"),
            "identity_checks": identity_checks,
            "identity_evidence": {
                "node_keys_sha256_a": source_a.get("node_keys_sha256"),
                "node_keys_sha256_b": source_b.get("node_keys_sha256"),
            },
            "masks_equal": masks_equal,
            "selection_a": selection_a.get("shared_ridge", {}).get(
                "selected_lambda"
            ),
            "selection_b": selection_b.get("shared_ridge", {}).get(
                "selected_lambda"
            ),
            "prediction_comparisons": prediction_comparisons,
            "metric_comparison": metric_comparison,
            "mae_relative_differences": mae_relative_differences,
            "cpu_relative_tolerance": CPU_RELATIVE_TOLERANCE,
            "seed_variance_reported": False,
            "status": "ok" if overall_ok else "mismatch",
        }
        check.write_json("report.json", report)
        check.write_text(
            "summary.md",
            f"# Compare check {run_id}\n\n"
            f"- Run A: `{run_a}`\n- Run B: `{run_b}`\n"
            f"- Result: {report['status']}\n"
            f"- Identities, selections and masks are compared before arrays;\n"
            f"  disagreement is reported as an execution difference, not seed variance.\n",
        )
        check.set_status("success" if overall_ok else "failed", stage="complete")
        check.finalize_artifacts_manifest()
        return {"run_dir": str(check.path), "status": report["status"], "report": report}
    except BaseException as exc:  # noqa: BLE001
        check.set_status("failed", stage="compare", error=repr(exc))
        raise


def _source_hash(source: Mapping[str, Any], name: str) -> Optional[str]:
    entry = source.get("sources", {}).get(name)
    return entry.get("sha256") if entry else None


# ---------------------------------------------------------------------------
# align-v2
# ---------------------------------------------------------------------------
def parse_v2_reference(path: Path) -> Dict[str, Any]:
    """Parse every JSON line of the sealed v2 diagnostic log."""
    records: List[Dict[str, Any]] = []
    for line_number, line in enumerate(
        Path(path).read_text(encoding="utf-8").splitlines(), start=1
    ):
        if not line.strip():
            continue
        try:
            records.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise CheckError(f"{path}:{line_number}: invalid JSON line: {exc}") from exc
    by_dataset: Dict[str, Dict[str, Any]] = {}
    for record in records:
        dataset = record.get("dataset")
        if dataset is None:
            continue
        bucket = by_dataset.setdefault(dataset, {"models": {}, "references": None})
        if "model" in record and "split" in record:
            bucket["models"][(record["split"], record["model"])] = record
        if "NaiveRef" in record:
            bucket["references"] = record
        if "split_windows" in record:
            bucket["windows"] = record
        if "activity_group_counts" in record:
            bucket["audit"] = record
    return {"records": records, "by_dataset": by_dataset}


def command_align_v2(
    *,
    run_dir: Path,
    reference: Path,
    run_id: str,
    runs_root: Path,
    repo_root: Path,
    command: Sequence[str],
) -> Dict[str, Any]:
    """Align a completed run's na\"ive results with the immutable v2 diagnostic."""
    run_dir, reference = Path(run_dir), Path(reference)
    if not run_dir.exists():
        raise CheckError(f"input run directory does not exist: {run_dir}")
    if not reference.exists():
        raise CheckError(f"v2 reference log does not exist: {reference}")
    reference_sha256 = sha256_file(reference)
    parsed = parse_v2_reference(reference)
    metrics_document = _read_json(run_dir / "metrics.json")
    audit = _read_json(run_dir / "audit.json")
    windows_meta = _read_json(run_dir / "windows.json")
    dataset = metrics_document["dataset"]
    bucket = parsed["by_dataset"].get(dataset)
    if bucket is None:
        raise CheckError(f"v2 reference log has no records for dataset {dataset!r}")

    check = _check_run(run_id, "align-v2", runs_root)
    try:
        _write_check_provenance(
            check,
            command=command,
            check="align-v2",
            repo_root=repo_root,
            inputs={
                "input_run_dir": str(run_dir),
                "reference_path": str(reference),
                "reference_sha256": reference_sha256,
                "input_artifacts": _hash_tree(
                    run_dir, ["metrics.json", "audit.json", "windows.json"]
                ),
            },
        )
        check.append_event("align_v2_started", reference=str(reference))
        checks: List[Dict[str, Any]] = []

        def add_scalar(field: str, expected: Any, actual: Any, *, numeric: bool = True) -> None:
            if expected is None and actual is None:
                checks.append(
                    {
                        "field": field,
                        "expected": expected,
                        "actual": actual,
                        "normalized_difference": 0.0,
                        "status": "ok",
                    }
                )
                return
            if numeric and isinstance(expected, (int, float)) and isinstance(
                actual, (int, float)
            ):
                difference = normalized_difference(float(expected), float(actual))
                checks.append(
                    {
                        "field": field,
                        "expected": expected,
                        "actual": actual,
                        "normalized_difference": difference,
                        "tolerance": DIAGNOSTIC_RELATIVE_TOLERANCE,
                        "status": "ok"
                        if difference <= DIAGNOSTIC_RELATIVE_TOLERANCE
                        else "mismatch",
                    }
                )
            else:
                checks.append(
                    {
                        "field": field,
                        "expected": expected,
                        "actual": actual,
                        "status": "ok" if expected == actual else "mismatch",
                    }
                )

        v2_audit = bucket.get("audit", {})
        for field in (
            "nodes",
            "skill_id_nunique",
            "joint_contexts",
            "context_cartesian_size",
            "expected_context_skill_nodes",
            "train_all_zero_fraction",
            "full_36_month_all_zero_fraction_diagnostic_only",
        ):
            if field in v2_audit:
                add_scalar(f"audit.{field}", v2_audit[field], audit.get(field))
        for key, value in v2_audit.get("activity_group_counts", {}).items():
            add_scalar(
                f"audit.activity_group_counts.{key}",
                value,
                audit.get("activity_group_counts", {}).get(key),
            )
        add_scalar(
            "audit.context_id_counts",
            v2_audit.get("context_id_counts"),
            audit.get("context_id_counts"),
            numeric=False,
        )
        add_scalar(
            "audit.is_complete_context_skill_grid",
            v2_audit.get("is_complete_context_skill_grid"),
            audit.get("is_complete_context_skill_grid"),
            numeric=False,
        )
        add_scalar(
            "audit.train_observation_months",
            v2_audit.get("train_observation_months"),
            audit.get("train_observation_months"),
            numeric=False,
        )

        v2_windows = bucket.get("windows", {})
        if "nodes" in v2_windows:
            add_scalar("audit.nodes", v2_windows["nodes"], audit.get("nodes"))
        add_scalar(
            "windows.split_windows",
            {key: list(value) for key, value in v2_windows.get("split_windows", {}).items()},
            {key: list(value) for key, value in windows_meta["splits"].items()},
            numeric=False,
        )
        actual_targets = {
            split: sorted(
                {
                    month
                    for start in starts
                    for month in protocol.window_target_months(start)
                }
            )
            for split, starts in windows_meta["splits"].items()
        }
        add_scalar(
            "windows.target_months",
            v2_windows.get("target_months"),
            actual_targets,
            numeric=False,
        )

        references = metrics_document.get("references", {})
        v2_references = bucket.get("references", {})
        add_scalar(
            "references.NaiveRef",
            v2_references.get("NaiveRef"),
            references.get("NaiveRef"),
            numeric=False,
        )
        add_scalar(
            "references.NaiveRef6",
            v2_references.get("NaiveRef6"),
            references.get("NaiveRef6"),
            numeric=False,
        )
        add_scalar(
            "references.SeasonalNaive12_information_budget",
            v2_references.get("SeasonalNaive12_information_budget"),
            references.get("information_budget", {}).get("SeasonalNaive12"),
            numeric=False,
        )

        methods = metrics_document["methods"]
        for (split, model), record in sorted(bucket["models"].items()):
            actual = methods.get(split, {}).get(model)
            if actual is None:
                checks.append(
                    {
                        "field": f"{split}.{model}",
                        "expected": "present in v2 reference",
                        "actual": None,
                        "status": "mismatch",
                    }
                )
                continue
            for field in ("MAE", "MSE", "RMSE"):
                if field in record:
                    add_scalar(f"{split}.{model}.{field}", record[field], actual.get(field))
            if "balanced_activity_group_MAE" in record:
                add_scalar(
                    f"{split}.{model}.balanced_activity_group_MAE",
                    record["balanced_activity_group_MAE"],
                    actual.get("balanced_activity_group_MAE"),
                )
            for horizon, values in record.get("horizons", {}).items():
                for field, value in values.items():
                    add_scalar(
                        f"{split}.{model}.horizons.{horizon}.{field}",
                        value,
                        actual.get("horizons", {}).get(horizon, {}).get(field),
                    )
            for group, values in record.get("activity_groups", {}).items():
                for field, value in values.items():
                    add_scalar(
                        f"{split}.{model}.activity_groups.{group}.{field}",
                        value,
                        actual.get("activity_groups", {}).get(group, {}).get(field),
                    )
            actual_windows = {
                row["forecast_origin"]: row for row in actual.get("windows", [])
            }
            for index, window in enumerate(record.get("windows", [])):
                origin = window.get("forecast_origin")
                actual_window = actual_windows.get(origin)
                if actual_window is None:
                    checks.append(
                        {
                            "field": f"{split}.{model}.windows[{index}]",
                            "expected": origin,
                            "actual": None,
                            "status": "mismatch",
                        }
                    )
                    continue
                for field in ("MAE", "MSE", "RMSE"):
                    add_scalar(
                        f"{split}.{model}.windows[{origin}].{field}",
                        window.get(field),
                        actual_window.get(field),
                    )
                add_scalar(
                    f"{split}.{model}.windows[{origin}].target_months",
                    window.get("target_months"),
                    actual_window.get("target_months"),
                    numeric=False,
                )

        discrepancies = [row for row in checks if row["status"] != "ok"]
        # Identity evidence: compare hashed source identities where available.
        identity_evidence: Dict[str, Any] = {
            "v2_log_contains_counts_not_full_node_keys": True,
            "run_node_keys_sha256": _read_json(run_dir / "source-sha256.json").get(
                "node_keys_sha256"
            ),
            "run_demand_sha256": _source_hash(
                _read_json(run_dir / "source-sha256.json"), "demand"
            ),
            "v2_source_sha256_available": False,
            "v2_source_sha256_demand": None,
            "identity_check_limitation": (
                "the v2 log reports aggregate counts rather than full canonical "
                "node keys, so row-level identity equality is established through "
                "the hashed demand source and canonical ordering, not from the log"
            ),
        }
        v2_source = reference.parent / "source-sha256.txt"
        if v2_source.exists():
            identity_evidence["v2_source_sha256_available"] = True
            identity_evidence["v2_source_sha256_file"] = str(v2_source)
            identity_evidence["v2_source_sha256_sha256"] = sha256_file(v2_source)
            for line in v2_source.read_text(encoding="utf-8").splitlines():
                parts = line.split()
                if len(parts) == 2 and parts[1].endswith(f"demand/{dataset}.parquet"):
                    identity_evidence["v2_source_sha256_demand"] = parts[0]
            identity_evidence["demand_sha256_matches_v2"] = (
                identity_evidence["v2_source_sha256_demand"]
                == identity_evidence["run_demand_sha256"]
            )

        report = {
            "check": "align-v2",
            "input_run_dir": str(run_dir),
            "reference_path": str(reference),
            "reference_sha256": reference_sha256,
            "reference_unchanged": sha256_file(reference) == reference_sha256,
            "dataset": dataset,
            "compared_fields": len(checks),
            "tolerance": DIAGNOSTIC_RELATIVE_TOLERANCE,
            "checks": checks,
            "discrepancies": discrepancies,
            "identity_evidence": identity_evidence,
            "diagnostic_elapsed_time_compared_as_cost": False,
            "status": "ok" if not discrepancies else "mismatch",
        }
        check.write_json("report.json", report)
        check.write_text(
            "summary.md",
            f"# align-v2 check {run_id}\n\n"
            f"- Input run: `{run_dir}`\n- Reference: `{reference}`\n"
            f"- Compared fields: {len(checks)}\n"
            f"- Discrepancies: {len(discrepancies)}\n"
            f"- Result: {report['status']}\n\n"
            "The reference log is read-only and was not modified. Diagnostic\n"
            "elapsed time is not compared with the new entry's measured cost.\n",
        )
        check.set_status("success" if not discrepancies else "failed", stage="complete")
        check.finalize_artifacts_manifest()
        return {"run_dir": str(check.path), "status": report["status"], "report": report}
    except BaseException as exc:  # noqa: BLE001
        check.set_status("failed", stage="align-v2", error=repr(exc))
        raise
